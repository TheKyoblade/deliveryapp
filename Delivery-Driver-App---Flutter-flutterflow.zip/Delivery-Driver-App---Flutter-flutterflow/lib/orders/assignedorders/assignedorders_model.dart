import '/flutter_flow/flutter_flow_util.dart';
import 'assignedorders_widget.dart' show AssignedordersWidget;
import 'package:flutter/material.dart';

class AssignedordersModel extends FlutterFlowModel<AssignedordersWidget> {
  ///  State fields for stateful widgets in this page.

  final unfocusNode = FocusNode();

  @override
  void initState(BuildContext context) {}

  @override
  void dispose() {
    unfocusNode.dispose();
  }
}
